package com.VMEDS.android.model;

/**
 * Created by Pratik on 2/22/2017.
 */
public class RGBColor {
    public float r_value, g_value, b_value, a_value;

    public RGBColor(float r_value, float g_value, float b_value, float a_value) {
        this.r_value = r_value;
        this.g_value = g_value;
        this.b_value = b_value;
        this.a_value = a_value;
    }
}
