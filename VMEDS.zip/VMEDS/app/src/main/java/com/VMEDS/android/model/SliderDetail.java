package com.VMEDS.android.model;

/**
 * Created by Pratik on 2/20/2017.
 */
public class SliderDetail {
    public String img_id, product_id, image, product_discription;

    public SliderDetail(String img_id, String product_id,  String product_discription,String image) {
        this.img_id = img_id;
        this.product_id = product_id;
        this.product_discription = product_discription;
        this.image = image;
    }
}
