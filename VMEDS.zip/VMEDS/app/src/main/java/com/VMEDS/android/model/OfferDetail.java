package com.VMEDS.android.model;

/**
 * Created by Yogesh on 6/8/2017.
 */

public class OfferDetail {

    public String id, name, description, amount;

    public OfferDetail(String id, String name, String description, String amount) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.amount = amount;
    }
}
