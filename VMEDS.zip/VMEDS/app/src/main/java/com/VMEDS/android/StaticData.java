package com.VMEDS.android;

/**
 * Created by Pratik on 2/20/2017.
 */
public class StaticData {
    public static String PAY2ALL_API_TOKEN = "CVmVpv7JD1JSOtZg2GbW8Cq9EhlYQZbroXGYG8CwP7NQMtZySeNWAfQCKHen";
    public static String BASE_URL = "http://genmeds.epicalci.com/index.php/";
    public static String CATEGORY_DATA_URL = "Product/productdata";
    public static String WHOLESALER_PRODUCT_URL = "F_product/fdata";
    public static String FEATURED_PRODUCT_URL = "Product/productdata";
    public static String CAT_URL = "Product/productdata";
    public static String HOME_IMAGE_SLIDER_URL = "Slider/sliderdata";
    public static String CATEGORY_URL = "Catagory/Catagorydata";
    public static String PRODUCT_DETAIL_URL = "Product/productdata";
    public static String SEARCH_URL = "Search/searchdata";
    public static final String REGISTER_URL = "Register/registerdata";
    public static final String FB_REGISTER_URL = "Facebook/fbdata";
    public static final String LOGIN_URL = "Login/checklogin";
    public static final String CONFIRM_OTP_URL = "Chkotp/checkotp";
    public static final String EDIT_PROFILE_URL = "Profile/editprofile";
    public static final String PAY2ALL_PROVIDER_API_URL = "https://www.pay2all.in/web-api/get-provider?api_token=";
    public static final String RECHARGE_PAYMENT_INSERT_API_URL = "Recharge_payment/paymentdata";
    public static final String RECHARGE_DATA_API_URL = "Recharge/rechargedata";
    public static final String CHANGE_PASSWORD_URL = "Change_pwd/pdata";
    public static final String FORGET_PASSWORD_OTP_URL = "Forget_1/fdata";
    public static final String FORGET_PASSWORD_CONFIRM_URL = "Forget_2/fdata";
    public static final String WISHLIST_INSERT_URL = "Wishlist/wishdata";
    public static final String WHOLESALER_LIST_URL = "wholesalers/lists/";
    public static final String WHOLESALER_DETAIL_URL = "wholesalers/detail/";
    public static final String WISHLIST_URL = "N_wish/wishdata";
    public static final String WISHLIST_DELETE_URL = "Wishlist_delete/del";
    public static final String OFFER_URL="Offers/ofr";
    public static final String BOOKING_URL="Booking/bdata";
    public static final String OFFER_APPLIED_URL="Check_ofr_code/odata";
    public static final String NOTIFICATION_URL="Notification/ndata";
    public static final String MYORDER_URL="Myorder/odata";
}
