package com.VMEDS.android.utils;

/**
 * Created by Pratik on 3/1/2017.
 */
public class MyOrder {
    public static final String TABLE = "MyOrder";

    public static final String USER_ID = "user_id";
    public static final String REF_ID = "ref_id";
    public static final String ORDER_DATE = "order_date";
    public static final String ADDRESS = "address";
    public static final String OFFER_APPLY = "offer_apply";
    public static final String OFFER_CODE = "offer_code";
    public static final String FINAL_TOTLE = "final_totle";
    public static final String STATUS = "status";
    public static final String CART_DATA = "cart_data";


    public String user_id, ref_id, order_date, address, offer_apply, offer_code, final_totle,  status ;
    public String cart_data;

}
