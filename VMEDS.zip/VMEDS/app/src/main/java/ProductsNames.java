/**
 * Created by dell on 12/21/2017.
 */

public class ProductsNames {
    private String productName;

    public ProductsNames(String productName) {
        this.productName = productName;
    }

    public String getAnimalName() {
        return this.productName;
    }

}
