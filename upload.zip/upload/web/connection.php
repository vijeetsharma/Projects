<?php 
//$cn=new MySqli('localhost','neelgupta','neha91221','test_calci')or die(mysql_error());

mysql_connect('localhost','neelgupta','neha91221');
mysql_select_db('test_calci')or die(mysql_error());
?>